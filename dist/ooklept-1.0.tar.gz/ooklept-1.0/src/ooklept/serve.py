# Serves a directory containing python files that uses ooklept Elements
# ooklept/serve.py

from pathlib import Path
import argparse

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse

app = FastAPI()

ROOT = Path.cwd()


@app.get("/{path:path}", response_class=HTMLResponse)
async def serve(path: str):
    global ROOT

    if path == "":
        path = "index.py"

    file = (ROOT / path).resolve()

    # Prevent directory traversal
    try:
        file.relative_to(ROOT.resolve())
    except ValueError:
        raise HTTPException(403)

    if not file.exists():
        raise HTTPException(404)

    if file.is_dir():
        file = file / "index.py"

    if not file.exists():
        raise HTTPException(404)

    return file.read_text(encoding="utf-8")


def main():
    global ROOT

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "directory",
        nargs="?",
        default=".",
        help="Directory to serve",
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)

    args = parser.parse_args()

    ROOT = Path(args.directory).resolve()

    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
