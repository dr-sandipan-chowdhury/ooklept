from ooklept import Element as el

el("p").text("Hello")
